package com.example.bulkupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulkuploadApplicationTests {

	@Test
	void contextLoads() {
	}

}